//Chart number 1
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart1);


var QNo1 = document.getElementById('QNo1').textContent;
var QNo6 = document.getElementById('QNo6').textContent;
var QNo11 = document.getElementById('QNo11').textContent;
var QNo16 = document.getElementById('QNo16').textContent;
var QNo21 = document.getElementById('QNo21').textContent;
var QNo26 = document.getElementById('QNo26').textContent;
var QNo31 = document.getElementById('QNo31').textContent;
var QNo36 = document.getElementById('QNo36').textContent;
var QNo41 = document.getElementById('QNo41').textContent;
var QNo46 = document.getElementById('QNo46').textContent;

    function drawChart1() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Q1",  parseInt(QNo1), "#b87333"],
        ["Q6",  parseInt(QNo6), "#0695a0"],
        ["Q11", parseInt(QNo11), "#c77272"],
        ["Q16", parseInt(QNo16), "#b87333"],
        ["Q21", parseInt(QNo21), "#0695a0"],
        ["Q26", parseInt(QNo26), "#c77272"],
        ["Q31", parseInt(QNo31), "#b87333"],
        ["Q36", parseInt(QNo36), "#0695a0"],
        ["Q41", parseInt(QNo41), "#c77272"],
        ["Q46", parseInt(QNo46), "#b87333"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 700,
        height: 500,
        bar: {groupWidth: "35%"},
        legend: { position: "none" },
         vAxis: { 
              viewWindow:{
                max:3,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("QuestionChart1"));
      chart.draw(view, options);
  }
//Chart number 1


//Chart number 2
   google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart2);


var QNo2 = document.getElementById('QNo2').textContent;
var QNo7 = document.getElementById('QNo7').textContent;
var QNo12 = document.getElementById('QNo12').textContent;
var QNo17 = document.getElementById('QNo17').textContent;
var QNo22 = document.getElementById('QNo22').textContent;
var QNo27 = document.getElementById('QNo27').textContent;
var QNo32 = document.getElementById('QNo32').textContent;
var QNo37 = document.getElementById('QNo37').textContent;
var QNo42 = document.getElementById('QNo42').textContent;
var QNo47 = document.getElementById('QNo47').textContent;

    function drawChart2() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Q2",  parseInt(QNo2), "#b87333"],
        ["Q7",  parseInt(QNo7), "#0695a0"],
        ["Q12", parseInt(QNo12), "#c77272"],
        ["Q17", parseInt(QNo17), "#b87333"],
        ["Q22", parseInt(QNo22), "#0695a0"],
        ["Q27", parseInt(QNo27), "#c77272"],
        ["Q32", parseInt(QNo32), "#b87333"],
        ["Q37", parseInt(QNo37), "#0695a0"],
        ["Q42", parseInt(QNo42), "#c77272"],
        ["Q47", parseInt(QNo47), "#b87333"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 700,
        height: 500,
        bar: {groupWidth: "35%"},
        legend: { position: "none" },
         vAxis: { 
              viewWindow:{
                max:3,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("QuestionChart2"));
      chart.draw(view, options);
  }
//Chart number 2



//Chart number 3
  
   google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart3);
var QNo3 = document.getElementById('QNo3').textContent;
var QNo8 = document.getElementById('QNo8').textContent;
var QNo13 = document.getElementById('QNo13').textContent;
var QNo18 = document.getElementById('QNo18').textContent;
var QNo23 = document.getElementById('QNo23').textContent;
var QNo28 = document.getElementById('QNo28').textContent;
var QNo33 = document.getElementById('QNo33').textContent;
var QNo38 = document.getElementById('QNo38').textContent;
var QNo43 = document.getElementById('QNo43').textContent;
var QNo48 = document.getElementById('QNo48').textContent;

    function drawChart3() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Q3",  parseInt(QNo3), "#b87333"],
        ["Q8",  parseInt(QNo8), "#0695a0"],
        ["Q13", parseInt(QNo13), "#c77272"],
        ["Q18", parseInt(QNo18), "#b87333"],
        ["Q23", parseInt(QNo23), "#0695a0"],
        ["Q28", parseInt(QNo28), "#c77272"],
        ["Q33", parseInt(QNo33), "#b87333"],
        ["Q38", parseInt(QNo38), "#0695a0"],
        ["Q43", parseInt(QNo43), "#c77272"],
        ["Q48", parseInt(QNo48), "#b87333"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options ={
        title: "",
        width: 700,
        height: 500,
        bar: {groupWidth: "35%"},
        legend: { position: "none" },
         vAxis: { 
              viewWindow:{
                max:3,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("QuestionChart3"));
      chart.draw(view, options);
  }
//Chart number 3



//Chart number 4
    
   google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart4);
var QNo4 = document.getElementById('QNo4').textContent;
var QNo9 = document.getElementById('QNo9').textContent;
var QNo14 = document.getElementById('QNo14').textContent;
var QNo19 = document.getElementById('QNo19').textContent;
var QNo24 = document.getElementById('QNo24').textContent;
var QNo29 = document.getElementById('QNo29').textContent;
var QNo34 = document.getElementById('QNo34').textContent;
var QNo39 = document.getElementById('QNo39').textContent;
var QNo44 = document.getElementById('QNo44').textContent;
var QNo49 = document.getElementById('QNo49').textContent;

    function drawChart4() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Q4",  parseInt(QNo4), "#b87333"],
        ["Q9",  parseInt(QNo9), "#0695a0"],
        ["Q14", parseInt(QNo14), "#c77272"],
        ["Q19", parseInt(QNo19), "#b87333"],
        ["Q24", parseInt(QNo24), "#0695a0"],
        ["Q29", parseInt(QNo29), "#c77272"],
        ["Q34", parseInt(QNo34), "#b87333"],
        ["Q39", parseInt(QNo39), "#0695a0"],
        ["Q44", parseInt(QNo44), "#c77272"],
        ["Q49", parseInt(QNo49), "#b87333"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 700,
        height: 500,
        bar: {groupWidth: "35%"},
        legend: { position: "none" },
         vAxis: { 
              viewWindow:{
                max:3,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("QuestionChart4"));
      chart.draw(view, options);
  }
//Chart number 4



//Chart number 5
   google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart5);
var QNo5 = document.getElementById('QNo5').textContent;
var QNo10 = document.getElementById('QNo10').textContent;
var QNo15 = document.getElementById('QNo15').textContent;
var QNo20 = document.getElementById('QNo20').textContent;
var QNo25 = document.getElementById('QNo25').textContent;
var QNo30 = document.getElementById('QNo30').textContent;
var QNo35 = document.getElementById('QNo35').textContent;
var QNo40 = document.getElementById('QNo40').textContent;
var QNo45 = document.getElementById('QNo45').textContent;
var QNo50 = document.getElementById('QNo50').textContent;

    function drawChart5() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Q5",  parseInt(QNo5), "#b87333"],
        ["Q10",  parseInt(QNo10), "#0695a0"],
        ["Q15", parseInt(QNo15), "#c77272"],
        ["Q20", parseInt(QNo20), "#b87333"],
        ["Q25", parseInt(QNo25), "#0695a0"],
        ["Q30", parseInt(QNo30), "#c77272"],
        ["Q35", parseInt(QNo35), "#b87333"],
        ["Q40", parseInt(QNo40), "#0695a0"],
        ["Q45", parseInt(QNo45), "#c77272"],
        ["Q50", parseInt(QNo50), "#b87333"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 700,
        height: 500,
        bar: {groupWidth: "35%"},
        legend: { position: "none" },
         vAxis: { 
              viewWindow:{
                max:3,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("QuestionChart5"));
      chart.draw(view, options);
  }
//Chart number 5

