//Chart number 1
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart1);


var actual1 = document.getElementById('actual1').textContent;
var avg1 = document.getElementById('avg1').textContent;
var max1 = document.getElementById('max1').textContent;

    function drawChart1() {
      var data1 = google.visualization.arrayToDataTable([
        ["", "", { role: "style" } ],
        ["Max", parseInt(max1), "#d03f32"],
        ["Actual", parseInt(actual1), "#3e9e1e"],
        ["Avarage", parseInt(avg1), "#4285f4"]
      ]);

      var view1 = new google.visualization.DataView(data1);
      view1.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
      
        width: 600,
        height: 200,
          legend: { position: "none" },
        vAxis: { 
              viewWindow:{
                max:30,
                min:0
              }   } 
      };

      var chart = new google.visualization.ColumnChart(document.getElementById("piechart1"));
      chart.draw(view1, options);
  }
//Chart number 1


//Chart number 2
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart2);


var actual2 = document.getElementById('actual2').textContent;
var avg2 = document.getElementById('avg2').textContent;
var max2 = document.getElementById('max2').textContent;

    function drawChart2() {
      var data2 = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Max", parseInt(max2), "#d03f32"],
        ["Actual", parseInt(actual2), "#3e9e1e"],
        ["Avarage", parseInt(avg2), "#4285f4"]
      ]);

      var view2 = new google.visualization.DataView(data2);
      view2.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 600,
        height: 200,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
        vAxis: { 
              viewWindow:{
                max:30,
                min:0
              }   } 
      };

      var chart2 = new google.visualization.ColumnChart(document.getElementById("piechart2"));
      chart2.draw(view2, options);
  }
//Chart number 2



//Chart number 3
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart3);


var actual3 = document.getElementById('actual3').textContent;
var avg3 = document.getElementById('avg3').textContent;
var max3 = document.getElementById('max3').textContent;

    function drawChart3() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Max", parseInt(max3), "#d03f32"],
        ["Actual", parseInt(actual3), "#3e9e1e"],
        ["Avarage", parseInt(avg3), "#4285f4"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 600,
        height: 200,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
        vAxis: { 
              viewWindow:{
                max:30,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("piechart3"));
      chart.draw(view, options);
  }
//Chart number 3



//Chart number 4
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart4);


var actual4 = document.getElementById('actual4').textContent;
var avg4 = document.getElementById('avg4').textContent;
var max4 = document.getElementById('max4').textContent;

    function drawChart4() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Max", parseInt(max4), "#d03f32"],
        ["Actual", parseInt(actual4), "#3e9e1e"],
        ["Avarage", parseInt(avg4), "#4285f4"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 600,
        height: 200,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
        vAxis: { 
              viewWindow:{
                max:30,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("piechart4"));
      chart.draw(view, options);
  }

//Chart number 4



//Chart number 5
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart5);


var actual5 = document.getElementById('actual5').textContent;
var avg5 = document.getElementById('avg5').textContent;
var max5 = document.getElementById('max5').textContent;

    function drawChart5() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "", { role: "style" } ],
        ["Max", parseInt(max5), "#d03f32"],
        ["Actual", parseInt(actual5), "#3e9e1e"],
        ["Avarage", parseInt(avg5), "#4285f4"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "",
        width: 600,
        height: 200,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
        vAxis: { 
              viewWindow:{
                max:30,
                min:0
              }   } 
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("piechart5"));
      chart.draw(view, options);
  }
//Chart number 5


//// Main Chart for cat

      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChartMain);

      function drawChartMain() {
        var data = google.visualization.arrayToDataTable([
          ['', 'Max', 'Actual', 'Avarage'],
          ['Focused Drive', parseInt(max1), parseInt(actual1), parseInt(avg1)],
          ['Emotional Intelligence', parseInt(max2), parseInt(actual2), parseInt(avg2)],
          ['Building Trust', parseInt(max3), parseInt(actual3), parseInt(avg3)],
          ['Conceptual Thinking', parseInt(max4), parseInt(actual4), parseInt(avg4)],
          ['Systems Thinking', parseInt(max5), parseInt(actual5), parseInt(avg5)],
        ]);

        var options = {
          chart: {
            title: '',
            subtitle: '',
          },
          bars: 'vertical',
          vAxis: {format: 'decimal'},
          height: 300,
          colors: ['#d03f32', '#3e9e1e', '#4285f4'],
        vAxis: { 
              viewWindow:{
                max:30,
                min:0
              }   } };

        var chart = new google.charts.Bar(document.getElementById('mainChartID'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
//// Main Chart for cat