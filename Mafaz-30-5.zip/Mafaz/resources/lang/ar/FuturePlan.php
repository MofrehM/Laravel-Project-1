<?php
return [
'FuturePlanHead'=>" الخطة المستقبلية",
'NameLFM'=>"الإسم (الأول - الثاني - اللقب)",
'LEVEL'=>"المستوى",
'DevelopmentObjective'=>"هدف التطوير",
'AreacompetencytoDevelop'=>"
مجال (الكفاءة) للتطوير",
'PURPOSE'=>"الهدف",
'PRIORITY'=>"الأهمية",
'ActivitiesActionStepstoDeveloptheCompetency'=>"الأنشطة (خطوات العمل) لتطوير الكفاءة",
'SuccessCriteriameasureKPIforsuccess'=>" معايير النجاح (قياس / KPI للنجاح)",
'Select'=>"اختر",
'HIGH'=>"عاليه",
'MEDIUM'=>"متوسطه",
'LOW'=>"منخفضة",
'CurrentScore'=>" الدرجة الحالية:",
'DesiredScore'=>"الدرجة المنشودة:",
'DateInput'=>"التاريخ",
'DiscussedwithCoachInput'=>"تم مناقشتها مع المدرب بتاريخ: ",
'Submit'=>"حفظ",
'YourPreviousPlans'=>"خطتك السابقه",

]
?>