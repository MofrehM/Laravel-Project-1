<?php
return [
'FuturePlanHead'=>"Future Plan Form:",
'NameLFM'=>"NAME (LAST, FIRST, MI)",
'LEVEL'=>"LEVEL",
'DevelopmentObjective'=>"Development Objective",
'AreacompetencytoDevelop'=>"Area (competency) to Develop",
'PURPOSE'=>"PURPOSE",
'PRIORITY'=>"PRIORITY",
'ActivitiesActionStepstoDeveloptheCompetency'=>"Activities (Action Steps) to Develop the Competency",
'SuccessCriteriameasureKPIforsuccess'=>" Success Criteria (measure / KPI for success)",
'Select'=>"Select",
'HIGH'=>"HIGH",
'MEDIUM'=>"MEDIUM",
'LOW'=>"LOW",
'CurrentScore'=>"Current Score:",
'DesiredScore'=>"Desired Score: ",
'DateInput'=>"Date",
'DiscussedwithCoachInput'=>"Discussed with Coach on (date): ",
'Submit'=>"Submit",
'YourPreviousPlans'=>"Your Previous Plans",
'CurrentScore'=>"Current Score:",
'DesiredScore'=>"Desired Score:",

]
?>