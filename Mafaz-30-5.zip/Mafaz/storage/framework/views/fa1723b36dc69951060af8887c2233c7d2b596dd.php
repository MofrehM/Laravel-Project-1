<?php echo e($slot); ?>

<?php /**PATH G:\Xampp\htdocs\Mafaz\Mafaz\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>